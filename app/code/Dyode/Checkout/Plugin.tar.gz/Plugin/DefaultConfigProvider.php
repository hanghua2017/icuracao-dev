<?php
namespace Dyode\Checkout\Plugin;

class DefaultConfigProvider
{
  public function __construct()
  {

  }
  public function afterGetConfig(\Magento\Checkout\Model\DefaultConfigProvider $subject, $result)

    foreach ($result['quoteItemData'] as $index => $quoteItem) {
      $this->collectProductShippingMethods($quoteItem);

        $result['quoteItemData'][$index]['shippingData'] = 'shipping details comes here';
    }
     return $result;
  }


  public function collectProductShippingMethods($quoteItem)
  {

  }

}
 ?>
